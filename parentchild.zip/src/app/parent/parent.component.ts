import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  public CData: number;
  public CCData: number;
  public childMess: string;
  message: String = '';
  name:String = '';
  public pValue: number;
  childMessage: String = '';

  showDataFromParent(data) {
    this.message = data;
  }
  
showValFromParent(data){
this.childMessage = data;
}
  constructor() { }

  ngOnInit() {
  }

}
