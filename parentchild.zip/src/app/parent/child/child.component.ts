import { Component, OnInit, Input, Output, EventEmitter  } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
@Input() PData:number;
@Input() message = 'I am from parent';
@Input() PCData:number;
@Input() name;
@Input() pvalue:number;
@Input() getParentValue: number;
@Input() getChild: number;


@Output() childEvent = new EventEmitter();
@Output() childEvents = new EventEmitter();
@Output() childMess = new EventEmitter();
@Output() sendMessage: EventEmitter<String> = new EventEmitter<String>();
@Output() sendChildData : EventEmitter<String> = new EventEmitter<String>();

  constructor() { }

  onChange(value){
    this.childEvent.emit(value);
  }

  onChangeValue(value){
    this.childEvents.emit(value);
  }
messageChild(value){
this.childMess.emit(value);
}

sendData(){
  this.sendMessage.emit('Hi i am coming from child');
}

sendChildValue(){
  this.sendChildData.emit('Hi data from child');
}
  ngOnInit() {
  }

}
