import { Component, OnInit } from '@angular/core';
import { DataService } from '../../data.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
    users: any;
  constructor(private data: DataService) { }

  ngOnInit() {
    this.data.getStudents().subscribe(data=> {
      this.users = data;
      console.log(this.data);
    })

    
}

}
