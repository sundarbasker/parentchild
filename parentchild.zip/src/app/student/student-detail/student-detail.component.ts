import { Component, OnInit } from '@angular/core';
import { EmployeesService } from '../../employees.service';

@Component({
  selector: 'app-student-detail',
  templateUrl: './student-detail.component.html',
  styleUrls: ['./student-detail.component.css']
})
export class StudentDetailComponent implements OnInit {
  emp: any;
  constructor(private data:EmployeesService) { }

  ngOnInit() {
    this.data.getEmployees().subscribe(data=>{
      this.emp = data;
      console.log('test data',this.data);
    });
  }

}
